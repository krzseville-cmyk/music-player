# Builds MusicPlayer.apk using only the Android SDK command-line tools (no Gradle needed).
# Usage:  powershell -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = "Stop"
$root  = $PSScriptRoot
$sdk   = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { "$env:LOCALAPPDATA\Android\Sdk" }
$bt    = Get-ChildItem "$sdk\build-tools" | Sort-Object { [version]($_.Name -replace '[^0-9.]','') } | Select-Object -Last 1 -ExpandProperty FullName
$plat  = Get-ChildItem "$sdk\platforms" | Sort-Object Name | Select-Object -Last 1 -ExpandProperty FullName
$jar   = "$plat\android.jar"
$out   = "$root\build"
$ks    = "$root\musicplayer.keystore"

function Run($exe, [string[]]$argv) {
    & $exe @argv
    if ($LASTEXITCODE -ne 0) { throw "Command failed ($LASTEXITCODE): $exe $argv" }
}

Write-Host "Using build-tools: $bt"
Write-Host "Using platform:    $plat"

& "$root\make_icons.ps1"
if (Test-Path $out) { Remove-Item -Recurse -Force $out }
New-Item -ItemType Directory -Force "$out\gen", "$out\classes", "$out\dex" | Out-Null

Write-Host "[1/6] Compiling resources"
Run "$bt\aapt2.exe" @("compile", "--dir", "$root\res", "-o", "$out\res.zip")
Run "$bt\aapt2.exe" @("link", "-o", "$out\unsigned.apk", "-I", $jar,
    "--manifest", "$root\AndroidManifest.xml", "--java", "$out\gen",
    "--min-sdk-version", "24", "--target-sdk-version", "35",
    "--version-code", "2", "--version-name", "2.0", "$out\res.zip")

Write-Host "[2/6] Compiling Java"
$sources = Get-ChildItem -Recurse "$root\src", "$out\gen" -Filter *.java | ForEach-Object { $_.FullName }
Run "javac" (@("-source", "8", "-target", "8", "-bootclasspath", "$jar;$bt\core-lambda-stubs.jar", "-encoding", "UTF-8",
    "-Xlint:-options", "-d", "$out\classes") + $sources)

Write-Host "[3/6] Converting to DEX"
Run "jar" @("cf", "$out\classes.jar", "-C", "$out\classes", ".")
Run "java" @("-cp", "$bt\lib\d8.jar", "com.android.tools.r8.D8", "--release", "--min-api", "24",
    "--lib", $jar, "--output", "$out\dex", "$out\classes.jar")

Write-Host "[4/6] Packaging"
Push-Location "$out\dex"
try { Run "$bt\aapt.exe" @("add", "$out\unsigned.apk", "classes.dex") } finally { Pop-Location }

Write-Host "[5/6] Aligning"
Run "$bt\zipalign.exe" @("-f", "-p", "4", "$out\unsigned.apk", "$out\aligned.apk")

Write-Host "[6/6] Signing"
if (-not (Test-Path $ks)) {
    Run "keytool" @("-genkeypair", "-keystore", $ks, "-alias", "musicplayer", "-keyalg", "RSA",
        "-keysize", "2048", "-validity", "10000", "-storepass", "android", "-keypass", "android",
        "-dname", "CN=Music Player")
}
Run "java" @("-jar", "$bt\lib\apksigner.jar", "sign", "--ks", $ks, "--ks-pass", "pass:android",
    "--key-pass", "pass:android", "--out", "$root\MusicPlayer.apk", "$out\aligned.apk")
Run "java" @("-jar", "$bt\lib\apksigner.jar", "verify", "$root\MusicPlayer.apk")

Write-Host "Done: $root\MusicPlayer.apk"
