# Generates the small vector icons used by the app (Material Design paths)
# and the launcher icon PNGs from "Glossy Black Vinyl Record Icon.png".
$dir = Join-Path $PSScriptRoot "res\drawable"
New-Item -ItemType Directory -Force $dir | Out-Null
$icons = @{
  "ic_play"       = "M8,5v14l11,-7z"
  "ic_pause"      = "M6,19h4V5H6v14zM14,5v14h4V5h-4z"
  "ic_next"       = "M6,18l8.5,-6L6,6v12zM16,6v12h2V6h-2z"
  "ic_prev"       = "M6,6h2v12H6zM9.5,12l8.5,6V6z"
  "ic_shuffle"    = "M10.59,9.17L5.41,4 4,5.41l5.17,5.17 1.42,-1.41zM14.5,4l2.04,2.04L4,18.59 5.41,20 17.96,7.46 20,9.5V4h-5.5zM14.83,13.41l-1.41,1.41 3.13,3.13L14.5,20H20v-5.5l-2.04,2.04 -3.13,-3.13z"
  "ic_repeat"     = "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4z"
  "ic_repeat_one" = "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4zM13,15V9h-1l-2,1v1h1.5v4H13z"
  "ic_music"      = "M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"
  "ic_search"     = "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z"
  "ic_close"      = "M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z"
  "ic_back"       = "M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z"
  "ic_expand"     = "M16.59,8.59L12,13.17 7.41,8.59 6,10l6,6 6,-6z"
  "ic_more"       = "M12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,16c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z"
  "ic_queue"      = "M15,6H3v2h12V6zM15,10H3v2h12v-2zM3,16h8v-2H3v2zM17,6v8.18c-0.31,-0.11 -0.65,-0.18 -1,-0.18 -1.66,0 -3,1.34 -3,3s1.34,3 3,3 3,-1.34 3,-3V8h3V6h-5z"
  "ic_playlist_add" = "M14,10H2v2h12v-2zM14,6H2v2h12V6zM18,14v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM2,16h8v-2H2v2z"
  "ic_drag"       = "M20,9H4v2h16V9zM4,15h16v-2H4v2z"
  "ic_add"        = "M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"
  "ic_album"      = "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,16.5c-2.49,0 -4.5,-2.01 -4.5,-4.5S9.51,7.5 12,7.5s4.5,2.01 4.5,4.5 -2.01,4.5 -4.5,4.5zM12,11c-0.55,0 -1,0.45 -1,1s0.45,1 1,1 1,-0.45 1,-1 -0.45,-1 -1,-1z"
  "ic_person"     = "M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z"
}
foreach ($name in $icons.Keys) {
  $xml = @"
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp"
    android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFFFF" android:pathData="$($icons[$name])" />
</vector>
"@
  [IO.File]::WriteAllText((Join-Path $dir "$name.xml"), $xml)
}

# ---- Launcher icon from the vinyl record PNG ----
$src = Join-Path $PSScriptRoot "Glossy Black Vinyl Record Icon.png"
if (-not (Test-Path $src)) { Write-Host "Launcher icon source not found, skipping"; return }
$stamp = Join-Path $PSScriptRoot "res\mipmap-xxxhdpi\ic_launcher.png"
if ((Test-Path $stamp) -and (Get-Item $stamp).LastWriteTime -gt (Get-Item $src).LastWriteTime) { return }

Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Bitmap]::FromFile($src)
try {
  # Crop to the opaque area so the record is centred regardless of the source padding.
  $rect = New-Object System.Drawing.Rectangle 0, 0, $img.Width, $img.Height
  $data = $img.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly,
      [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $bytes = New-Object byte[] ($data.Stride * $img.Height)
  [Runtime.InteropServices.Marshal]::Copy($data.Scan0, $bytes, 0, $bytes.Length)
  $img.UnlockBits($data)
  $minX = $img.Width; $minY = $img.Height; $maxX = -1; $maxY = -1
  for ($y = 0; $y -lt $img.Height; $y++) {
    $row = $y * $data.Stride
    for ($x = 0; $x -lt $img.Width; $x++) {
      if ($bytes[$row + $x * 4 + 3] -gt 40) {
        if ($x -lt $minX) { $minX = $x }; if ($x -gt $maxX) { $maxX = $x }
        if ($y -lt $minY) { $minY = $y }; if ($y -gt $maxY) { $maxY = $y }
      }
    }
  }
  $side = [Math]::Max($maxX - $minX, $maxY - $minY) + 1
  $cx = ($minX + $maxX) / 2.0; $cy = ($minY + $maxY) / 2.0
  $crop = New-Object System.Drawing.RectangleF ([float]($cx - $side / 2)), ([float]($cy - $side / 2)), ([float]$side), ([float]$side)

  function Save-Icon($size, $recordFraction, $bg, $path) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.Clear($bg)
    $d = $size * $recordFraction
    $o = ($size - $d) / 2
    $dest = New-Object System.Drawing.RectangleF ([float]$o), ([float]$o), ([float]$d), ([float]$d)
    $g.DrawImage($img, $dest, $crop, [System.Drawing.GraphicsUnit]::Pixel)
    $g.Dispose()
    New-Item -ItemType Directory -Force (Split-Path $path) | Out-Null
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
  }

  $densities = @{ "mdpi" = 1.0; "hdpi" = 1.5; "xhdpi" = 2.0; "xxhdpi" = 3.0; "xxxhdpi" = 4.0 }
  foreach ($d in $densities.Keys) {
    $s = $densities[$d]
    $res = Join-Path $PSScriptRoot "res\mipmap-$d"
    # Legacy icon: the record on a transparent background.
    Save-Icon ([int](48 * $s)) 0.92 ([System.Drawing.Color]::Transparent) (Join-Path $res "ic_launcher.png")
    # Adaptive foreground: 108dp canvas, record sized to fill the 72dp mask area.
    Save-Icon ([int](108 * $s)) 0.70 ([System.Drawing.Color]::Transparent) (Join-Path $res "ic_launcher_fg.png")
  }
} finally {
  $img.Dispose()
}
